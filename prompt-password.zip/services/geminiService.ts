import { GoogleGenAI } from "@google/genai";
import type { ScoreResult, VerificationResult } from '../types';

if (!process.env.API_KEY) {
    console.error("API_KEY environment variable not set.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });

const parseJsonResponse = <T,>(text: string): T | null => {
    let jsonStr = text.trim();
    const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
    const match = jsonStr.match(fenceRegex);
    if (match && match[2]) {
      jsonStr = match[2].trim();
    }
    try {
      return JSON.parse(jsonStr) as T;
    } catch (e) {
      console.error("Failed to parse JSON response:", e, "Raw text:", text);
      return null;
    }
}

export const scorePasswordRule = async (prompt: string): Promise<ScoreResult> => {
    const systemPrompt = `You are a security expert. Your only job is to evaluate if a user's PASSWORD RULE is secure. A secure rule is a pattern, formula, or behavior, NOT a static password.

STRICTLY REJECT rules that are just fixed passwords.
- "my password is 'password123'" -> REJECT
- "supersecret" -> REJECT

ENTHUSIASTICALLY APPROVE rules that describe a process.
- "I will type three colors followed by the current day of the week." -> APPROVE
- "My dog's name spelled backwards plus the number of windows in my room." -> APPROVE
- "I will express frustration about traffic." -> APPROVE

Respond ONLY with a single JSON object in the format: {"isSecure": boolean, "score": number (0-100), "feedback": "A very brief explanation for your score."}`;

    const userMessage = `Evaluate the following password rule: "${prompt}"`;

    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash-preview-04-17",
            contents: userMessage,
            config: {
                systemInstruction: systemPrompt,
                responseMimeType: "application/json",
                temperature: 0.1,
            },
        });

        const result = parseJsonResponse<ScoreResult>(response.text);
        if (result) {
            return result;
        }
        throw new Error("LLM did not return a valid JSON object for scoring.");

    } catch (error) {
        console.error("Password rule scoring failed:", error);
        return { isSecure: false, score: 0, feedback: "An error occurred while evaluating the rule. Please try again." };
    }
};

export const verifyPassword = async (prompt: string, password: string): Promise<VerificationResult> => {
    const systemPrompt = `You are an authentication verifier. Your only job is to determine if a user's PASSWORD INPUT correctly follows their PASSWORD RULE.

Be strict with the rule but flexible with minor variations. The core pattern is what matters.

EXAMPLES:
- Rule: "I will be arrogant about technology" -> Input: "Modern tech is trash and I am smarter than all developers" -> isValid: true
- Rule: "A European city, then the phrase '2+2=5'" -> Input: "Paris 2+2=5" -> isValid: true
- Rule: "A European city, then the phrase '2+2=5'" -> Input: "Paris 2+2=4" -> isValid: false (The rule's specific error was not matched)

Respond ONLY with a single JSON object in the format: {"isValid": boolean, "confidence": number (0.0-1.0), "explanation": "A brief reason for your decision."}`;

    const userMessage = `Password Rule: "${prompt}"\n\nPassword Input: "${password}"\n\nDoes the input perfectly follow the rule?`;
    
    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash-preview-04-17",
            contents: userMessage,
            config: {
                systemInstruction: systemPrompt,
                responseMimeType: "application/json",
                temperature: 0.1,
            },
        });
        
        const result = parseJsonResponse<VerificationResult>(response.text);
        if (result) {
            return result;
        }
        throw new Error("LLM did not return a valid JSON object for verification.");

    } catch (error) {
        console.error("Password verification failed:", error);
        return { isValid: false, confidence: 0.0, explanation: "Verification service failed. Please try again." };
    }
};