
import React, { useState, useCallback } from 'react';
import { AppStep } from './types';
import SetupStep from './components/SetupStep';
import LoginStep from './components/LoginStep';

const App: React.FC = () => {
  const [appStep, setAppStep] = useState<AppStep>(AppStep.Setup);
  const [passwordRule, setPasswordRule] = useState<string | null>(null);
  const [encryptionQuestion, setEncryptionQuestion] = useState<string | null>(null);
  const [encryptionAnswer, setEncryptionAnswer] = useState<string | null>(null);
  const [username, setUsername] = useState<string | null>(null);
  const [email, setEmail] = useState<string | null>(null);

  const LOGO_URL = "https://avatars.githubusercontent.com/u/208861345?v=4";

  const handleRuleSet = useCallback((rule: string, question: string, answer: string, username?: string, email?: string) => {
    setPasswordRule(rule);
    setEncryptionQuestion(question);
    setEncryptionAnswer(answer);
    setUsername(username || null);
    setEmail(email || null);
    setAppStep(AppStep.PracticeLogin);
  }, []);

  const handlePracticeSuccess = useCallback(() => {
    setAppStep(AppStep.Completed);
  }, []);

  const handleReset = useCallback(() => {
    setPasswordRule(null);
    setEncryptionQuestion(null);
    setEncryptionAnswer(null);
    setUsername(null);
    setEmail(null);
    setAppStep(AppStep.Setup);
  }, []);

  const handleLogoClick = (e: React.MouseEvent<HTMLAnchorElement>) => {
    e.preventDefault();
    handleReset();
  };

  return (
    <div className="bg-black text-zinc-100 min-h-screen flex flex-col items-center justify-center p-4 font-sans">
      <div className="w-full max-w-2xl mx-auto relative">
        <header className="text-center mb-8">
          {appStep !== AppStep.Completed && (
             <a href="#" onClick={handleLogoClick} className="absolute top-0 left-0 transition-opacity hover:opacity-80">
                <img src={LOGO_URL} alt="Logo" className="w-12 h-12" />
              </a>
          )}
          <h1 className="text-4xl font-bold tracking-tight text-white sm:text-5xl mb-4 pt-4 sm:pt-0">
              Prompt Password
          </h1>
          <p className="mt-2 text-lg text-zinc-400">
            A way you think, not a word you think.
          </p>
        </header>

        <main>
          {appStep === AppStep.Setup && (
            <SetupStep onRuleSet={handleRuleSet} />
          )}
          {appStep === AppStep.PracticeLogin && passwordRule && (
            <LoginStep 
              rule={passwordRule} 
              onSuccess={handlePracticeSuccess}
              username={username}
            />
          )}
          {appStep === AppStep.Completed && (
            <div className="text-center flex flex-col items-center justify-center gap-6 mt-8">
                <h2 className="text-3xl font-bold text-green-400">Your Account is Now Complete</h2>
                <p className="text-zinc-300">You have successfully created and verified your cognitive password.</p>
                <a href="#" onClick={handleLogoClick} className="mt-4 group">
                    <img src={LOGO_URL} alt="Go Home" className="w-24 h-24 transition-all group-hover:scale-105" />
                </a>
                <p className="text-zinc-500">Click the logo to start over.</p>
            </div>
          )}
        </main>
        
        <footer className="text-center mt-12 text-zinc-500 text-sm">
            <p>An Innovation Activated by Starpower</p>
        </footer>
      </div>
    </div>
  );
};

export default App;
