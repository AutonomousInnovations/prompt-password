import React from 'react';

interface CardProps {
    children: React.ReactNode;
}

const Card: React.FC<CardProps> = ({ children }) => {
    return (
        <div className="bg-zinc-900/50 border border-zinc-800 rounded-xl shadow-2xl shadow-black/50 p-6 sm:p-8 backdrop-blur-sm">
            {children}
        </div>
    );
};

export default Card;
