import React, { useState, useCallback } from 'react';
import { scorePasswordRule } from '../services/geminiService';
import type { ScoreResult } from '../types';
import { ShieldCheck, ShieldOff, KeyRound, ArrowRight, User, Mail, HelpCircle } from 'lucide-react';
import Spinner from './shared/Spinner';
import Card from './shared/Card';

interface SetupStepProps {
  onRuleSet: (rule: string, question: string, answer: string, username?: string, email?: string) => void;
}

const ScoreMeter: React.FC<{ score: number }> = ({ score }) => {
  const getScoreColor = (s: number) => {
    if (s < 40) return 'bg-red-500';
    if (s < 75) return 'bg-yellow-500';
    return 'bg-green-500';
  };

  return (
    <div className="w-full bg-zinc-700 rounded-full h-4 my-2">
      <div
        className={`h-4 rounded-full transition-all duration-500 ${getScoreColor(score)}`}
        style={{ width: `${score}%` }}
      ></div>
    </div>
  );
};


const SetupStep: React.FC<SetupStepProps> = ({ onRuleSet }) => {
  const [rule, setRule] = useState('');
  const [encryptionQuestion, setEncryptionQuestion] = useState('');
  const [encryptionAnswer, setEncryptionAnswer] = useState('');
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [scoreResult, setScoreResult] = useState<ScoreResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleScoreRule = useCallback(async () => {
    if (!rule) {
      setError('Please enter a password rule.');
      return;
    }
    setError(null);
    setIsLoading(true);
    setScoreResult(null);
    try {
      const result = await scorePasswordRule(rule);
      setScoreResult(result);
    } catch (e) {
      setError('An unexpected error occurred.');
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  }, [rule]);

  const handleSave = () => {
    if (scoreResult && scoreResult.isSecure && rule && encryptionQuestion && encryptionAnswer) {
        onRuleSet(rule, encryptionQuestion, encryptionAnswer, username, email);
    }
  }

  const isSaveDisabled = !scoreResult || !scoreResult.isSecure || !encryptionQuestion || !encryptionAnswer || isLoading;

  return (
    <Card>
      <div className="flex flex-col gap-6">
        <div>
          <h2 className="text-2xl font-semibold text-white text-center">Create Your Rule</h2>
          <p className="text-zinc-400 mt-1 text-center">Create a memorable rule or pattern. This is not a password, but a formula for creating one.</p>
        </div>
        
        <div className="relative">
            <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-zinc-400" />
            <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Username"
                className="w-full bg-zinc-800 border border-zinc-700 rounded-md py-2.5 pl-10 pr-4 text-white placeholder-zinc-400 focus:ring-2 focus:ring-teal-500 focus:outline-none"
            />
        </div>
        <div className="relative">
            <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-zinc-400" />
            <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Email Address"
                className="w-full bg-zinc-800 border border-zinc-700 rounded-md py-2.5 pl-10 pr-4 text-white placeholder-zinc-400 focus:ring-2 focus:ring-teal-500 focus:outline-none"
            />
        </div>

        <div className="relative">
            <textarea
                value={rule}
                onChange={(e) => setRule(e.target.value)}
                placeholder="e.g., 3 girl names with all capital vowels + 3 odd numbers"
                className="w-full bg-zinc-800 border border-zinc-700 rounded-md py-2.5 px-4 text-white placeholder-zinc-400 focus:ring-2 focus:ring-teal-500 focus:outline-none resize-none"
                rows={3}
            />
        </div>

        <button
          onClick={handleScoreRule}
          disabled={isLoading || !rule}
          className="w-full flex justify-center items-center bg-teal-600 text-white font-bold py-2.5 px-4 rounded-md hover:bg-teal-500 disabled:bg-zinc-700 disabled:cursor-not-allowed transition-colors"
        >
          {isLoading ? <Spinner /> : 'Score My Rule'}
        </button>

        {error && <p className="text-red-400 text-center">{error}</p>}
        
        {scoreResult && (
          <div className="bg-zinc-800/50 p-4 rounded-lg border border-zinc-700 space-y-3">
            <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold flex items-center gap-2">
                    {scoreResult.isSecure ? <ShieldCheck className="text-green-400"/> : <ShieldOff className="text-red-400"/>}
                    Security Analysis
                </h3>
                <span className={`font-bold ${scoreResult.isSecure ? 'text-green-400' : 'text-red-400'}`}>
                    {scoreResult.isSecure ? 'Secure' : 'Insecure'}
                </span>
            </div>
            <p className="text-zinc-300">{scoreResult.feedback}</p>
            <div className="flex items-center gap-4">
                <span className="text-sm font-medium text-zinc-400">Score: {scoreResult.score}/100</span>
                <ScoreMeter score={scoreResult.score} />
            </div>
          </div>
        )}
        
        <div className="relative">
            <HelpCircle className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-zinc-400" />
            <input
                type="text"
                value={encryptionQuestion}
                onChange={(e) => setEncryptionQuestion(e.target.value)}
                placeholder="Create Encryption Question"
                className="w-full bg-zinc-800 border border-zinc-700 rounded-md py-2.5 pl-10 pr-4 text-white placeholder-zinc-400 focus:ring-2 focus:ring-teal-500 focus:outline-none"
            />
        </div>

        <div className="relative">
            <KeyRound className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-zinc-400" />
            <input
                type="password"
                value={encryptionAnswer}
                onChange={(e) => setEncryptionAnswer(e.target.value)}
                placeholder="How Will You Answer"
                className="w-full bg-zinc-800 border border-zinc-700 rounded-md py-2.5 pl-10 pr-4 text-white placeholder-zinc-400 focus:ring-2 focus:ring-teal-500 focus:outline-none"
            />
        </div>

        <button
            onClick={handleSave}
            disabled={isSaveDisabled}
            className="w-full flex justify-center items-center gap-2 bg-teal-600 text-white font-bold py-2.5 px-4 rounded-md hover:bg-teal-500 disabled:bg-zinc-700 disabled:text-zinc-400 disabled:cursor-not-allowed transition-colors"
        >
            Save & Continue
            <ArrowRight className="w-5 h-5" />
        </button>
      </div>
    </Card>
  );
};

export default SetupStep;
