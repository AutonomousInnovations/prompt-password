import React, { useState, useCallback } from 'react';
import { verifyPassword } from '../services/geminiService';
import type { VerificationResult } from '../types';
import { Fingerprint, CheckCircle2, XCircle, KeyRound } from 'lucide-react';
import Spinner from './shared/Spinner';
import Card from './shared/Card';


interface LoginStepProps {
  rule: string;
  onSuccess: () => void;
  username: string | null;
}

const ConfidenceMeter: React.FC<{ confidence: number }> = ({ confidence }) => {
  const getConfidenceColor = (c: number) => {
    if (c < 0.4) return 'bg-red-500';
    if (c < 0.75) return 'bg-yellow-500';
    return 'bg-green-500';
  };
  const percentage = Math.round(confidence * 100);

  return (
    <div className="w-full bg-zinc-700 rounded-full h-2.5 my-2">
      <div
        className={`h-2.5 rounded-full transition-all duration-500 ${getConfidenceColor(confidence)}`}
        style={{ width: `${percentage}%` }}
      ></div>
    </div>
  );
};

const LoginStep: React.FC<LoginStepProps> = ({ rule, onSuccess, username }) => {
  const [passwordAttempt, setPasswordAttempt] = useState('');
  const [verificationResult, setVerificationResult] = useState<VerificationResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleVerify = useCallback(async () => {
    if (!passwordAttempt) {
      setError('Please enter a password attempt.');
      return;
    }
    setError(null);
    setIsLoading(true);
    setVerificationResult(null);
    try {
      const result = await verifyPassword(rule, passwordAttempt);
      setVerificationResult(result);
      if (result.isValid) {
        setTimeout(() => {
          onSuccess();
        }, 1500);
      }
    } catch (e) {
      setError('An unexpected error occurred during verification.');
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  }, [passwordAttempt, rule, onSuccess]);

  return (
    <Card>
      <div className="flex flex-col gap-6">
        <div className="text-center">
            <h2 className="text-2xl font-semibold text-white">Practice Authentication</h2>
            {username ? (
              <p className="text-zinc-400 mt-1">Hello <span className="font-semibold text-zinc-300">{username}</span>! Enter a password that follows your rule.</p>
            ) : (
              <p className="text-zinc-400 mt-1">Enter a password that follows your rule.</p>
            )}
        </div>
        
        <div className="bg-zinc-800/50 p-4 rounded-lg border border-zinc-700">
            <p className="text-sm text-zinc-400 mb-1 font-semibold">Your Password Rule:</p>
            <p className="text-zinc-200 font-mono">"{rule}"</p>
        </div>
        
        <div className="relative">
            <KeyRound className="absolute left-3 top-3 w-5 h-5 text-zinc-400" />
            <textarea
                value={passwordAttempt}
                onChange={(e) => setPasswordAttempt(e.target.value)}
                placeholder="Enter password based on your rule"
                className="w-full bg-zinc-800 border border-zinc-700 rounded-md py-2.5 pl-10 pr-4 text-white placeholder-zinc-400 focus:ring-2 focus:ring-teal-500 focus:outline-none resize-none"
                rows={3}
            />
        </div>

        <button
          onClick={handleVerify}
          disabled={isLoading || !passwordAttempt}
          className="w-full flex justify-center items-center gap-2 bg-teal-600 text-white font-bold py-2.5 px-4 rounded-md hover:bg-teal-500 disabled:bg-zinc-700 disabled:cursor-not-allowed transition-colors"
        >
          {isLoading ? <Spinner /> : <Fingerprint className="w-5 h-5" />}
          Verify Practice Attempt
        </button>

        {error && <p className="text-red-400 text-center">{error}</p>}
        
        {verificationResult && (
          <div className={`p-4 rounded-lg border ${verificationResult.isValid ? 'bg-green-900/20 border-green-500/30' : 'bg-red-900/20 border-red-500/30'}`}>
              <div className="flex items-center gap-3">
                  {verificationResult.isValid 
                    ? <CheckCircle2 className="w-8 h-8 text-green-400 flex-shrink-0" /> 
                    : <XCircle className="w-8 h-8 text-red-400 flex-shrink-0" />
                  }
                  <div>
                      <h3 className={`text-lg font-semibold ${verificationResult.isValid ? 'text-green-300' : 'text-red-300'}`}>
                          {verificationResult.isValid ? 'Verification Successful' : 'Verification Failed'}
                      </h3>
                      <p className="text-zinc-300 text-sm">{verificationResult.explanation}</p>
                  </div>
              </div>
               <div className="mt-3">
                    <p className="text-sm font-medium text-zinc-400">Confidence: {Math.round(verificationResult.confidence * 100)}%</p>
                    <ConfidenceMeter confidence={verificationResult.confidence} />
               </div>
          </div>
        )}
      </div>
    </Card>
  );
};

export default LoginStep;
