export enum AppStep {
  Setup,
  PracticeLogin,
  Completed,
}

export interface ScoreResult {
  isSecure: boolean;
  score: number;
  feedback: string;
}

export interface VerificationResult {
  isValid: boolean;
  confidence: number;
  explanation: string;
}
